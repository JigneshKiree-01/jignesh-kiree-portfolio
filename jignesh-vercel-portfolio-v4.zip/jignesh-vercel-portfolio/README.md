# Jignesh Kiree — Portfolio

Responsive single-page portfolio prepared for Vercel.

## Deploy
1. Create a GitHub repository and upload `index.html` from this folder to the repository root.
2. Open https://vercel.com/new and import the GitHub repository.
3. For a static HTML site, choose **Other** as the framework preset. Leave the build command empty and set the output directory to `.` if prompted.
4. Click **Deploy**. After deployment succeeds, Vercel will provide a public URL ending in `vercel.app`.

## Typography
Aptos Display is the global font family, with Aptos, Segoe UI and Arial fallbacks. The exact font depends on whether it is available on the viewer’s device. Include a properly licensed webfont and `@font-face` declaration for consistent rendering across devices.

## Content notes
Role descriptions are based on the supplied CV. The $1.55 million USD active-customer-discussion figure was supplied by the portfolio owner and should be verified before public publication.
